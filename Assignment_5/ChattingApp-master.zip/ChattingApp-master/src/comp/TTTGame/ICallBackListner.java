package comp.TTTGame;

public interface ICallBackListner {

	public void buttonClicked(int position);
}
