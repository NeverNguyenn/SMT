package com.pla.chatsys;

public interface IPrintEvent {

	
	public void print(String msg);
}
