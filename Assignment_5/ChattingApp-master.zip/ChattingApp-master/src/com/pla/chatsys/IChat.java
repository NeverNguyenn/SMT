package com.pla.chatsys;

public interface IChat {
	
public void sendMessage(String sender, String message);
}
