package com.pla.chatsys;

public interface IFileSentListener {
	
	public void fileSent(String sender,String fileName,byte[] fileData);

}
