package com.pla.chatsys;

public interface ITempletSend {
	
	/*public void sendTextTemplet(String sender,String text);
	
	public void sendImageTemplet(String sender,String img);
	
	public void sendMultimediaTemplet(String sender,String code);*/
	
	
	public void sendTemplet(String sender,String code);

}
