package com.pla.chatsys;

public interface ITTT {
	
	public void startTTT(int x, int y);
	
	public void endTTT();
	
	public void opponentMove(int position);

}
