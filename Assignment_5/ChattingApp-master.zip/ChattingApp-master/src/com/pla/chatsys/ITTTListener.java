package com.pla.chatsys;

public interface ITTTListener {

	public void myMove(int position);
	
	public void quit();
	
}
