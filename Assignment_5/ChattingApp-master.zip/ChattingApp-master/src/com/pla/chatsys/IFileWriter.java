package com.pla.chatsys;


public interface IFileWriter {
	
	public boolean writeMsg(String sender,String message);
	

}
