package com.pla.chatsys;

public interface IChatListener {
public void messageSent(String sender, String message);
}
