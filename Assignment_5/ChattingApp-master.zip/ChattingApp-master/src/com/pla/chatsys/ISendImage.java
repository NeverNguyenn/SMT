package com.pla.chatsys;

public interface ISendImage {

	public void sendImage(String sender,String path,byte[] data);
}
