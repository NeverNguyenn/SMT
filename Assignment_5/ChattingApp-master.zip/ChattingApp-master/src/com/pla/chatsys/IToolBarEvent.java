package com.pla.chatsys;

public interface IToolBarEvent {

	public void onColorReceived(int color);
	
	public void onLocationReceived(double lat,double lon);
	
	
}
