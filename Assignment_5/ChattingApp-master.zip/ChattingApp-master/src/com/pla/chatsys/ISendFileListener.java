package com.pla.chatsys;

public interface ISendFileListener {
	
	public void sendFile(String sender,String path,byte[] fileData);

}
